# machine_learning_basic
Repo for everyone who wants a machine learning basic
